0.21 Dev Build Only - For testing

Miner Name
==========

Get your name on the miner list rather than your mining address?

1. Send exctly 1 Bismuth from your mining address to the same mining address with the following in the "data" field:

Minername=your name here

Whatever is after the = sign will appear as your name in the miner list

2. Let the transaction confirm and then run "bismuthtool_dev.exe" from your bismuth folder (as administrator). Make sure you delete your existing miner.db file before you run the tool (or overwrite it with the one provided)

3. Once the miner.db update has completed (see status bar at bottom) click refresh on the Miner Query Page
